class Items{
  String id;
  String image;
  String name;
  int price;
  int guests;
  String location;
  String description;
  Items(this.id,this.image, this.name, this.price,this.guests, this.location, this.description);
}
